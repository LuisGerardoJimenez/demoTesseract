/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();
    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter)
        regexp = new RegExp(seriesFilter, 'i');

    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            var newRow = tBody.insertRow(-1);
            for(var col=0; col < item.data.length; col++){
                var cell = newRow.insertCell(-1);
                cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 28.571428571428573, "KoPercent": 71.42857142857143};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
               "color" : "red"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "blue"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round(series.percent)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.2857142857142857, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)  ", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "PHCUSPR17-TP10"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR11-TP40"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP60model.autor"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP70model.book"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP70model.autor"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP70model.editorial"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR17.2-TP10"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP60model.level"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP70model.level"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP60model.book"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP50year"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP70year"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.2-TP4TP80"], "isController": false}, {"data": [1.0, 500, 1500, "PJCUSPR17.2-TP80"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 14, 10, 71.42857142857143, 286.0, 453.0, 453.0, 9.04977375565611, 74.73954124919199, 46, 453], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "90th pct", "95th pct", "99th pct", "Throughput", "KB/sec", "Min", "Max"], "items": [{"data": ["PHCUSPR17-TP10", 1, 0, 0.0, 119.0, 119.0, 119.0, 8.403361344537815, 98.6328125, 119, 119], "isController": false}, {"data": ["PHCUSPR11-TP40", 1, 0, 0.0, 70.0, 70.0, 70.0, 14.285714285714285, 3.585379464285714, 70, 70], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP60model.autor", 1, 1, 100.0, 61.0, 61.0, 61.0, 16.393442622950822, 152.2156762295082, 61, 61], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP70model.book", 1, 1, 100.0, 60.0, 60.0, 60.0, 16.666666666666668, 156.33138020833334, 60, 60], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP70model.autor", 1, 1, 100.0, 87.0, 87.0, 87.0, 11.494252873563218, 108.98213002873564, 87, 87], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP70model.editorial", 1, 1, 100.0, 64.0, 64.0, 64.0, 15.625, 146.484375, 64, 64], "isController": false}, {"data": ["PHCUSPR17.2-TP10", 1, 0, 0.0, 70.0, 70.0, 70.0, 14.285714285714285, 147.01450892857142, 70, 70], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP60model.level", 1, 1, 100.0, 59.0, 59.0, 59.0, 16.949152542372882, 157.30932203389833, 59, 59], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP70model.level", 1, 1, 100.0, 71.0, 71.0, 71.0, 14.084507042253522, 131.4233054577465, 71, 71], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP60model.book", 1, 1, 100.0, 78.0, 78.0, 78.0, 12.82051282051282, 118.99038461538461, 78, 78], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP50year", 1, 1, 100.0, 64.0, 64.0, 64.0, 15.625, 145.172119140625, 64, 64], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP70year", 1, 1, 100.0, 55.0, 55.0, 55.0, 18.18181818181818, 168.90980113636363, 55, 55], "isController": false}, {"data": ["PHCUSPR17.2-TP4TP80", 1, 1, 100.0, 46.0, 46.0, 46.0, 21.73913043478261, 201.97860054347825, 46, 46], "isController": false}, {"data": ["PJCUSPR17.2-TP80", 1, 0, 0.0, 453.0, 453.0, 453.0, 2.207505518763797, 0.1228787251655629, 453, 453], "isController": false}]}, function(index, item){
        switch(index){
            case 3:
                item = item.toFixed(2) + '%';
                break;
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Test failed: text expected to contain \/Enter 4 digits\/", 2, 20.0, 14.285714285714286], "isController": false}, {"data": ["Test failed: text expected to contain \/This field is mandatory.\/", 4, 40.0, 28.571428571428573], "isController": false}, {"data": ["Test failed: text expected to contain \/Enter less than 100 characters.\/", 6, 60.0, 42.857142857142854], "isController": false}, {"data": ["Test failed: text expected to contain \/Successful edition\/", 2, 20.0, 14.285714285714286], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);
});
