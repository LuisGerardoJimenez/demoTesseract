/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();
    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter)
        regexp = new RegExp(seriesFilter, 'i');

    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            var newRow = tBody.insertRow(-1);
            for(var col=0; col < item.data.length; col++){
                var cell = newRow.insertCell(-1);
                cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 73.33333333333333, "KoPercent": 26.666666666666668};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
               "color" : "red"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "blue"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round(series.percent)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7333333333333333, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)  ", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "PHCUSPR17-TP10"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR11-TP40"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR17.1-TP4TP60model.autor"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.1-TP4TP70model.autor"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR17.1-TP4TP70model.editorial"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR17.1-TP4TP60model.book"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR17.1-TP4TP70model.level"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR17.1-TP4TP50year"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR17.1-TP10"], "isController": false}, {"data": [1.0, 500, 1500, "PJCUSPR17.1-TP80"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR17.1-TP4TP60model.level"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.1-TP4TP70year"], "isController": false}, {"data": [0.0, 500, 1500, "PHCUSPR17.1-TP4TP80"], "isController": false}, {"data": [1.0, 500, 1500, "PHCUSPR17.1-TP4TP70model.book"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 15, 4, 26.666666666666668, 273.20000000000016, 479.0, 479.0, 7.451564828614009, 68.19249099602584, 78, 479], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "90th pct", "95th pct", "99th pct", "Throughput", "KB/sec", "Min", "Max"], "items": [{"data": ["PHCUSPR17-TP10", 1, 0, 0.0, 136.0, 136.0, 136.0, 7.352941176470588, 86.29653033088235, 136, 136], "isController": false}, {"data": ["PHCUSPR11-TP40", 1, 0, 0.0, 79.0, 79.0, 79.0, 12.658227848101266, 3.176918512658228, 79, 79], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP60model.autor", 1, 0, 0.0, 92.0, 92.0, 92.0, 10.869565217391305, 113.04772418478261, 92, 92], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP70model.autor", 2, 2, 100.0, 101.0, 101.0, 101.0, 5.5096418732782375, 58.421573691460054, 80, 101], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP70model.editorial", 1, 0, 0.0, 97.0, 97.0, 97.0, 10.309278350515465, 108.34809922680412, 97, 97], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP60model.book", 1, 0, 0.0, 80.0, 80.0, 80.0, 12.5, 130.029296875, 80, 80], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP70model.level", 1, 0, 0.0, 90.0, 90.0, 90.0, 11.11111111111111, 115.92881944444444, 90, 90], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP50year", 1, 0, 0.0, 86.0, 86.0, 86.0, 11.627906976744185, 121.0483284883721, 86, 86], "isController": false}, {"data": ["PHCUSPR17.1-TP10", 1, 0, 0.0, 78.0, 78.0, 78.0, 12.82051282051282, 131.58553685897436, 78, 78], "isController": false}, {"data": ["PJCUSPR17.1-TP80", 1, 0, 0.0, 479.0, 479.0, 479.0, 2.08768267223382, 0.1162088987473904, 479, 479], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP60model.level", 1, 0, 0.0, 121.0, 121.0, 121.0, 8.264462809917356, 85.76801394628099, 121, 121], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP70year", 1, 1, 100.0, 126.0, 126.0, 126.0, 7.936507936507936, 82.54278273809524, 126, 126], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP80", 1, 1, 100.0, 87.0, 87.0, 87.0, 11.494252873563218, 118.56815732758622, 87, 87], "isController": false}, {"data": ["PHCUSPR17.1-TP4TP70model.book", 1, 0, 0.0, 87.0, 87.0, 87.0, 11.494252873563218, 120.77945402298852, 87, 87], "isController": false}]}, function(index, item){
        switch(index){
            case 3:
                item = item.toFixed(2) + '%';
                break;
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Test failed: text expected to contain \/Enter only letters\/", 2, 50.0, 13.333333333333334], "isController": false}, {"data": ["Test failed: text expected to contain \/Enter less than 50 characters.\/", 3, 75.0, 20.0], "isController": false}, {"data": ["Test failed: text expected to contain \/Successful registration\/", 2, 50.0, 13.333333333333334], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);
});
